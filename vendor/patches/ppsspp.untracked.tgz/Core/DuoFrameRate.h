#pragma once
namespace CoreTiming {
// CPU-thread only; 0 restores the game's latest requested frequency.
void DuoSetClockFloorHz(int hz);
}
